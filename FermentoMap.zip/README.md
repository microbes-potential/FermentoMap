# FermentoMap

A Python library for detecting fermentation-relevant traits in microbial genomes.